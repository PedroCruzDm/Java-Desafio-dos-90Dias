class Main { //código 05
  public static void main(String[] args) {
   int numero1 = 4;
   int numero2 = 3;
  int resultado1 = numero1 + numero2;
if(resultado1 > 9) {
      System.out.print("Esse resultado foi maior que 9. o Resultado foi: " +resultado1);
    }
else {
  System.out.print("O resultado é muito baixo!");
}

int item = 5;
switch(item) {
  case 1:
      System.out.print("Temos apenas 1 item. ");
      break;
  case 2:
      System.out.print("Temos apenas 2 itens. ");
  case 3:
      System.out.print("Temos apenas 3 itens. ");
     break;
      case 4:
        System.out.println("Temos apenas 4 itens. ");
        break;
      case 5:
        System.out.println("Temos apenas 5 itens. ");
        break;
      case 6:
        System.out.println("Temos apenas 6 itens. ");
        break;
      case 7:
        System.out.println("Temos apenas 7 itens. ");
        break;
    }
    System.out.print("vamos usar LOOP"); //código 06

int i = 0;
    while(i < 10) {
      System.out.print("  " + i);
      i++;
    }

  }
}