public class Main {
  public static void main(String[] args) {
    System.out.print("Ola, estou começando" );
    System.out.print(" JAVA!, uma linguagem nova "); // código 01 
    System.out.print("Printando Números em Java : "); //código 02
    System.out.print(1);
    System.out.print(2);
    System.out.print(3);
int valor1 = 10; //código 03
int valor2 = 2;
int resultado1 = valor1 + valor2;
    System.out.print(" Somando valor de " +valor1 + " com " +valor2 +" , o resultado será: ");
    System.out.print(resultado1); 

String texto = "   Testando letras"; //código 04 
    System.out.print(texto.toUpperCase()); //MAIUSCULAS
    System.out.print(texto.toLowerCase()); //minusculas

    System.out.print("Finalizamos o dia 01 parte 1/2");
  }
}
